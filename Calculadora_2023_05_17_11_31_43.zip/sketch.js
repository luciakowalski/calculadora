class tecla{
  constructor(x,y){
    this.x=x;
    this.y=y;
    this.color=("rgb(59,55,55)");
    fill(this.color);
    square(this.x,this.y,20);
  }
}
class pantalla{
  constructor(x,y){
  this.x=x;
    this.y=y;
    this.color=("rgb(200,206,200)");
    fill(this.color);
    rect(this.x,this.y,200,100);
  }
}

class Calculadora{
  constructor(){
    this.pantalla=new pantalla (50, 50)
    this.tecla1=new tecla(50,250)
    this.tecla2=new tecla(50,300)
    this.tecla3=new tecla(50,350)
    this.tecla4=new tecla(150,250)
    this.tecla5=new tecla(150,300)
    this.tecla6=new tecla(150,350)
    this.tecla7=new tecla(100,250)
    this.tecla8=new tecla(100,300)
    this.tecla9=new tecla(100,350)
    this.tecla10=new tecla(225,250)
    this.tecla11=new tecla(225,300)
    this.tecla12=new tecla(225,350)
    this.tecla13=new tecla(225,200)
    this.tecla14=new tecla(50,200)
    this.tecla15=new tecla(100,200)
    this.tecla16=new tecla(150,200)
    
    
    this.resultado=resultado;
    
  }
  
  suma(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1+n2;
  }
  
  resta(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1-n2;
  }
  
  multiplicación(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1*n2;
  }
  
  división(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1/n2;
  }
  
  
  dimeResultado(){
    console.log("Resultado:",this.resultado);
  }
  
  
}  

class CalculadoraCientifica extends Calculadora{
  constructor(){
    super(n1, n2);
  }
  división(n1, n2){
  if (n2==0){
   console.log("Syntax error");
  this.resultado=0}
   else {this.resultado=n1/n2;}
  
  }
  
  cuadrado(n1){
  //multiplicación=(n1);
    this.resultado=n1*n1;
    
    //n1 se multiplica a sí mismo para hallar el cuadrado
  }
}

let n1;
let n2;
let calculadora1;
let resultado;
let calculadorac;

function setup() {

  createCanvas (300,400);
  background("rgb(132,132,134)");
  calculadora1=new Calculadora();
  calculadorac=new CalculadoraCientifica();
  calculadora1.suma(9, 3);
  calculadora1.dimeResultado();
  calculadora1.resta(9, 3);
  calculadora1.dimeResultado();
  calculadora1.multiplicación(9, 3);
  calculadora1.dimeResultado();
  calculadorac.división(18, 0);
  calculadorac.dimeResultado();
  calculadorac.cuadrado(18);
  calculadorac.dimeResultado();
  
    
}