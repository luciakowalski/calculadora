class Calculadora{
  constructor(){
    this.resultado=resultado;
    
  }
  
  suma(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1+n2;
  }
  
  resta(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1-n2;
  }
  
  multiplicación(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1*n2;
  }
  
  división(n1, n2){
    this.n1=n1;
    this.n2=n2;
    this.resultado=n1/n2;
  }
  
  
  dimeResultado(){
    console.log("Resultado:",this.resultado);
  }
  
  
}  




//añadir calculadora científica

let n1;
let n2;
let calculadora1;
let resultado;

function setup() {

  calculadora1=new Calculadora();
  calculadora1.suma(9, 3);
  calculadora1.dimeResultado();
  calculadora1.resta(9, 3);
  calculadora1.dimeResultado();
  calculadora1.multiplicación(9, 3);
  calculadora1.dimeResultado();
  calculadora1.división(9, 0);
  

  
    
}